import React from 'react';
import { Link } from 'react-router-dom';
import floridaPeppermintCover from '../assets/florida_peppermint_book_cover.jpeg';
import grandmasLapCover from '../assets/Grandma\'s Lap.JPG';
import fathersVoiceCover from '../assets/I know My Father\'s Voice.jpg';

const BooksPage = () => {
  const handlePayPalPurchase = (bookTitle, price) => {
    // PayPal email from user input
    const paypalEmail = "clomanregina7@gmail.com";
    
    // Base price from user input
    const basePrice = price;
    
    // Shipping cost from user input
    const shippingCost = 3.00;
    

    
    // Create PayPal URL
    const paypalUrl = `https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=${encodeURIComponent(paypalEmail)}&item_name=${encodeURIComponent(bookTitle)}&amount=${basePrice}&shipping=${shippingCost}&currency_code=USD`;
    
    // Open in new window
    window.open(paypalUrl, '_blank');
  };

  return (
    <div className="py-12 bg-gray-50" data-sb-object-id="bookspage">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-serif text-burgundy mb-8 text-center" data-sb-field-path="pageTitle">Books by Regina Cloman-Moore</h1>
        
        {/* Bulk Discount Banner */}
        <div className="bg-gold text-burgundy p-4 rounded-lg shadow-md mb-12 text-center" data-sb-object-id="bulk-discount-banner">
          <p className="text-xl font-bold mb-2" data-sb-field-path="bannerTitle">Interested in Bulk Discounts for Schools or Organizations?</p>
          <p className="text-lg" data-sb-field-path="bannerDescription">
            We offer special pricing for bulk orders of 10 or more books. Perfect for schools, libraries, and educational programs. 
            Please <a href="/contact" class="underline font-semibold">contact us</a> for a custom quote!
          </p>
        </div>
        
        {/* Book Categories Tabs */}
        <div className="flex justify-center mb-12">
          <button className="px-6 py-3 bg-burgundy text-white font-bold rounded-l">Children's Books</button>
          <button className="px-6 py-3 bg-gray-300 text-gray-700 font-bold">Adult Books</button>
          <button className="px-6 py-3 bg-gray-300 text-gray-700 font-bold rounded-r">Journals</button>
        </div>
        
        {/* Books Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Florida Peppermint Book */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden" data-sb-object-id="florida-peppermint-book">
            <div className="flex justify-center">
              <img 
                src={floridaPeppermintCover} 
                alt="Florida Peppermint Goes To School" 
                className="w-full h-80 object-contain"
                data-sb-field-path="bookCover"
              />
            </div>
            <div className="p-6">
              <h3 className="text-2xl font-serif text-burgundy mb-2" data-sb-field-path="bookTitle">Florida Peppermint Goes To School</h3>
              <p className="text-gray-600 mb-4" data-sb-field-path="bookDescription">
                August 23rd was just an ordinary day for some, but for Florida Peppermint, this was the most exciting day of her entire life. It was the beginning of a new school year, and Florida would be going to school for the very first time.
              </p>
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm text-gray-500" data-sb-field-path="publishDate">Published: March 5, 2025</span>
                <Link to="/books/florida-peppermint" className="text-burgundy font-bold hover:text-gold transition-colors">
                  Learn More
                </Link>
              </div>
              <div className="mt-4">
                <div className="space-y-3">
                  <div className="border rounded-lg p-3">
                    <p className="font-bold text-lg mb-1">Paperback: $15.00 <span className="text-sm font-normal">(+$3.00 shipping)</span></p>
                    <button 
                      onClick={() => handlePayPalPurchase("Florida Peppermint Goes To School - Paperback", 15.00)}
                      className="w-full bg-burgundy hover:bg-opacity-90 text-white py-2 px-4 rounded transition-colors"
                    >
                      Buy Paperback with PayPal
                    </button>
                  </div>
                  <div className="border rounded-lg p-3">
                    <p className="font-bold text-lg mb-1">Hardcover: $20.00 <span className="text-sm font-normal">(+$3.00 shipping)</span></p>
                    <button 
                      onClick={() => handlePayPalPurchase("Florida Peppermint Goes To School - Hardcover", 20.00)}
                      className="w-full bg-burgundy hover:bg-opacity-90 text-white py-2 px-4 rounded transition-colors"
                    >
                      Buy Hardcover with PayPal
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* I Know My Father's Voice Book */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden" data-sb-object-id="fathers-voice-book">
            <div className="flex justify-center">
              <img 
                src={fathersVoiceCover} 
                alt="I Know My Father's Voice" 
                className="w-full h-80 object-contain"
                data-sb-field-path="bookCover"
              />
            </div>
            <div className="p-6">
              <h3 className="text-2xl font-serif text-burgundy mb-2" data-sb-field-path="bookTitle">I Know My Father's Voice</h3>
              <p className="text-gray-600 mb-4" data-sb-field-path="bookDescription">
                Journey along with Florida as she experiences adventure, joy, and a little fear. On this journey, Florida discovers that no matter what happens or where she may be, her father is always near. All she has to do is listen for his voice!
              </p>
              <div className="mt-4">
                <div className="space-y-3">
                  <div className="border rounded-lg p-3">
                    <p className="font-bold text-lg mb-1" data-sb-field-path="englishVersionPrice">English Version: $15.00 <span className="text-sm font-normal">(+$3.00 shipping)</span></p>
                    <p className="text-burgundy font-bold mb-2" data-sb-field-path="englishVersionOffer">Comes with a FREE coloring book!</p>
                    <button 
                      onClick={() => handlePayPalPurchase("I Know My Father's Voice (English Version with FREE coloring book)", 15.00)}
                      className="w-full bg-burgundy hover:bg-opacity-90 text-white py-2 px-4 rounded transition-colors"
                    >
                      Buy English Version with PayPal
                    </button>
                  </div>
                  <div className="border rounded-lg p-3">
                    <p className="font-bold text-lg mb-1" data-sb-field-path="spanishVersionPrice">Spanish Version: $15.00 <span className="text-sm font-normal">(+$3.00 shipping)</span></p>
                    <p className="text-gray-600 mb-2" data-sb-field-path="spanishVersionNote">(Does not include coloring book)</p>
                    <button 
                      onClick={() => handlePayPalPurchase("I Know My Father's Voice (Spanish Version)", 15.00)}
                      className="w-full bg-burgundy hover:bg-opacity-90 text-white py-2 px-4 rounded transition-colors"
                    >
                      Buy Spanish Version with PayPal
                    </button>
                  </div>
                </div>
              </div>
              <div className="flex justify-between items-center mb-4 mt-4">
                <span className="text-sm text-gray-500" data-sb-field-path="publishDate">Published: 2024</span>
                <Link to="/books/fathers-voice" className="text-burgundy font-bold hover:text-gold transition-colors">
                  Learn More
                </Link>
              </div>
            </div>
          </div>
          
          {/* Grandma's Lap Book */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden" data-sb-object-id="grandmas-lap-book">
            <div className="flex justify-center">
              <img 
                src={grandmasLapCover} 
                alt="Grandma's Lap" 
                className="w-full h-80 object-contain"
                data-sb-field-path="bookCover"
              />
            </div>
            <div className="p-6">
              <h3 className="text-2xl font-serif text-burgundy mb-2" data-sb-field-path="bookTitle">Grandma's Lap</h3>
              <p className="text-gray-600 mb-4" data-sb-field-path="bookDescription">
                A heartwarming children's book about the special bond between a grandmother and her grandchildren.
              </p>
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm text-gray-500" data-sb-field-path="publishDate">Published: 2024</span>
                <Link to="/books/grandmas-lap" className="text-burgundy font-bold hover:text-gold transition-colors">
                  Learn More
                </Link>
              </div>
              <div className="mt-4">
                <p className="font-bold text-lg mb-1">$12.00 <span className="text-sm font-normal">(+$3.00 shipping)</span></p>
                <button 
                  onClick={() => handlePayPalPurchase("Grandma's Lap", 12.00)}
                  className="w-full bg-burgundy hover:bg-opacity-90 text-white py-2 px-4 rounded transition-colors"
                >
                  Buy Now with PayPal
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BooksPage;
